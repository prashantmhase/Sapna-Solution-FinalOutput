package com.sapnasolution.problem;

import java.io.FileOutputStream;

public class Main {

	public static void main(String[] args) throws Exception {
		CategoryTree categoryTree = new CategoryTree("category.txt", "\\");
		
		StringBuffer primaryCategorySbuff = categoryTree.getCategoryTree();
		System.out.println(primaryCategorySbuff+"\r\n");
		
		FileOutputStream out = new FileOutputStream("Output.txt");
		out.write(new String(primaryCategorySbuff).getBytes());
	}

}
