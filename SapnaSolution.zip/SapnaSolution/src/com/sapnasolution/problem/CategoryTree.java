package com.sapnasolution.problem;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
/**
 * This class reads the file line by line and Process each Line to Populate category Tree.
 * @author Rembo
 *
 */
public class CategoryTree {
	
	private String fileName = null;
	private String delimiter = null ;
	
	public CategoryTree(String fileName, String delimiter) {
		this.fileName = fileName;
		this.delimiter = delimiter;
	}
	/**
	 * This method is used to read the file line by line and process each line to get category Tree
	 * @return
	 * @throws Exception
	 */
	public StringBuffer getCategoryTree() throws Exception {
		Hashtable primaryCategories = new Hashtable();
		Hashtable subCategories = new Hashtable();
		List secondLevelSubCatList = new ArrayList();
		String categoryName = null;
		String subCategoryName = null;

		BufferedReader br = new BufferedReader(new FileReader(this.fileName));
		String line = br.readLine();
	
		while(line != null) {
			line = line.replaceAll("\\{", "");
			line = line.replaceAll("\\}", "");
			StringTokenizer stringTokenizer = new StringTokenizer(line, this.delimiter);
			String secondSubCatName= null;
			secondLevelSubCatList = new ArrayList();
			
			while(stringTokenizer.hasMoreElements()){
				String token = stringTokenizer.nextToken();
				if(!token.startsWith("|") && !token.startsWith("**")) {
					categoryName = token;
				}
				else if(token.startsWith("|")) {
					 subCategoryName = token.replace("|", "");
				}
				else if(token.startsWith("**")) {
					secondSubCatName = token.replace("**", "");
				}
				
				if(subCategoryName != null) { 
					if(subCategories.containsKey(subCategoryName) && secondSubCatName != null){
						((List)subCategories.get(subCategoryName)).add(secondSubCatName);
					}
					else {
						if(secondSubCatName != null){
							secondLevelSubCatList.add(secondSubCatName);
						}
						subCategories.put(subCategoryName, secondLevelSubCatList);
					}
				} 
				if(categoryName != null) {
					if(primaryCategories.containsKey(categoryName)) {
						primaryCategories.remove(categoryName);
						primaryCategories.put(categoryName, subCategories);
					}
					else {
						primaryCategories.put(categoryName, subCategories);
						subCategories = new Hashtable();
					}
				}
		}
			line = br.readLine();
		}
		// in primaryCategories hastable we are having details of each category. 
		return getCategoryTree(primaryCategories);
	}
	/**
	 * This method is used to get the formatted output. 
	 * @param primaryCategories
	 * @return
	 */
	private StringBuffer getCategoryTree(Hashtable primaryCategories) {
		
		Hashtable subCategories = new Hashtable();
		List secondLevelSubCatList = new ArrayList();
		
		Enumeration primaryCategoryKeys = primaryCategories.keys();
		StringBuffer primaryCategorySbuff = new StringBuffer();
		while(primaryCategoryKeys.hasMoreElements()) {
			String primaryCategoryKey = (String) primaryCategoryKeys.nextElement();
			subCategories = (Hashtable)primaryCategories.get(primaryCategoryKey);
			
			Enumeration subCategoryKeys = subCategories.keys();
			StringBuffer subCategorySbuff = new StringBuffer();
			while(subCategoryKeys.hasMoreElements()) {
				String subCategoryKey = (String) subCategoryKeys.nextElement();
				secondLevelSubCatList = (List)subCategories.get(subCategoryKey);
				Iterator iter = secondLevelSubCatList.iterator();
				StringBuffer secondLevelSubCatSbuff = new StringBuffer();
				while(iter.hasNext()) {
					String secondSubCatName = (String)iter.next();
					secondLevelSubCatSbuff.append(":- "+secondSubCatName+"\r\n\t\t\t\t\t");
				}
				subCategorySbuff.append( subCategoryKey+" >> "+secondLevelSubCatSbuff+"\r\n\t\t");
			}
			primaryCategorySbuff.append(primaryCategoryKey+" >> "+subCategorySbuff+"\r\n");
		}
		return primaryCategorySbuff;
	}
}
